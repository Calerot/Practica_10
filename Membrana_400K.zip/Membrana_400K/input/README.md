Initial coordinates from
https://terpconnect.umd.edu/~jbklauda/memb.html


The psf file has been regenerated using VMD autopsf to be in NAMD psf format
